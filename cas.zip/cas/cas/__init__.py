from .celery import app as capp

__all__ = ['capp']
