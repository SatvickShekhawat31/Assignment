from django.contrib import admin
from .models import Customer, Loan

admin.site.register(Customer)
admin.site.register(Loan)
